import { FLOWER_ICON, getAnimalLevelFromXp, computePigTradeIn } from "./calculator.js";

import { collectCaveDugToday, readCaveDugToday } from "./cave_solver.js";

const STORE_KEY = "hl_daily_harvest_v1";

const ROUND_THRESHOLD = 1;

let memStore = null;

function utcDay(ms) {
  return new Date(ms).toISOString().slice(0, 10);
}

function utcDayStart(ms) {
  const d = new Date(ms);
  return Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate());
}

function pruneStore(store) {
  const today = utcDay(Date.now());
  const active = store.__last;
  let changed = false;
  Object.keys(store).forEach(k => {
    if (k === "__last") return;
    const rec = store[k];
    if (!rec || typeof rec !== "object") {
      delete store[k];
      changed = true;
      return;
    }
    if (rec.day === today) return;
    if (k === active) {
      if (Object.keys(rec.stats || {}).length || Object.keys(rec.prev || {}).length || rec.cook && rec.cook.prev && Object.keys(rec.cook.prev).length || rec.bris && rec.bris.known) {
        store[k] = {
          day: rec.day,
          prev: rec.prev || {},
          stats: {},
          counters: rec.counters || {},
          inv: rec.inv || {},
          act: rec.act || {},
          power: rec.power || {},
          amts: rec.amts || {},
          ym: rec.ym || {},
          cc: rec.cc || {},
          syncAt: rec.syncAt || 0,
          cook: carryCook(rec.cook),
          bris: carryBris(rec.bris)
        };
        changed = true;
      }
      return;
    }
    delete store[k];
    changed = true;
  });
  return changed;
}

function loadStore() {
  if (memStore) return memStore;
  try {
    const raw = localStorage.getItem(STORE_KEY);
    const parsed = raw ? JSON.parse(raw) : null;
    memStore = parsed && typeof parsed === "object" ? parsed : {};
  } catch (e) {
    memStore = {};
  }
  if (pruneStore(memStore)) saveStore();
  return memStore;
}

function freshStore() {
  const store = loadStore();
  if (pruneStore(store)) saveStore();
  return store;
}

function saveStore() {
  try {
    localStorage.setItem(STORE_KEY, JSON.stringify(memStore || {}));
  } catch (e) {}
}

function numTs(v) {
  return typeof v === "number" && v > 0 ? v : 0;
}

function isActiveNode(node, now) {
  if (!node || typeof node !== "object") return false;
  return !(typeof node.removedAt === "number" && node.removedAt <= now);
}

const yieldMeta = {};

let metaFarm = "";

const RESOLVABLE_GROUPS = {
  Wood: true,
  Stone: true,
  Iron: true,
  Gold: true
};

const ACT_KEY_RE = /^(.+ Tree Chopped|.+ Rock Mined)$/;

var pendResolver;

var cookProvider;

const LOG_NAME_RE = /^[A-Za-z0-9 '&.\-]{1,40}$/;

export function dailyHarvestSetCookingProvider(fn) {
  cookProvider = typeof fn === "function" ? fn : null;
}

function carryCook(c) {
  return {
    prev: c && c.prev && typeof c.prev === "object" ? c.prev : {},
    ctr: c && c.ctr && typeof c.ctr === "object" ? c.ctr : {},
    hint: c && c.hint && typeof c.hint === "object" ? c.hint : {},
    totals: {},
    bld: {},
    known: !!(c && c.known)
  };
}

var priceProvider;

export function dailyHarvestSetPriceProvider(fn) {
  priceProvider = typeof fn === "function" ? fn : null;
}

function lookupPrice(name) {
  if (!priceProvider) return {
    price: 0,
    fee: 0
  };
  try {
    const r = priceProvider(name);
    return {
      price: r && r.price > 0 ? r.price : 0,
      fee: r && r.fee > 0 ? r.fee : 0
    };
  } catch (e) {
    return {
      price: 0,
      fee: 0
    };
  }
}

const BRISTLE_KEY = "Pig Bristles Collected";

function carryBris(b) {
  return {
    ctr: b && typeof b.ctr === "number" ? b.ctr : 0,
    inv: b && typeof b.inv === "number" ? b.inv : 0,
    pigs: b && b.pigs && typeof b.pigs === "object" ? b.pigs : {},
    known: !!(b && b.known),
    a: 0,
    c: 0,
    log: []
  };
}

function pigSnapshot(g) {
  const animals = g.pigpen && g.pigpen.animals && typeof g.pigpen.animals === "object" ? g.pigpen.animals : null;
  if (!animals) return null;
  const out = {};
  Object.keys(animals).forEach(id => {
    const pig = animals[id];
    if (!pig || typeof pig !== "object") return;
    const xp = Number(pig.experience ?? pig.exp ?? pig.xp);
    out[id] = {
      x: Number.isFinite(xp) ? xp : 0,
      s: typeof pig.state === "string" ? pig.state : "",
      m: Number(pig.multiplier) > 0 ? Number(pig.multiplier) : 0
    };
  });
  return out;
}

function pigBristlesFor(pig) {
  let level = getAnimalLevelFromXp("pig", pig.x, true);
  if (pig.s === "ready" && level < 15) level -= 1;
  const base = computePigTradeIn(level);
  if (!base.tradeable) return {
    level: level,
    amount: 0
  };
  let amount = pig.m > 0 ? base.amount * pig.m : base.amount;
  if (pig.s === "sick") amount *= .75;
  return {
    level: level,
    amount: Math.round(amount * 100) / 100
  };
}

function trackBristles(g, rec, fresh, now, prevSyncAt, start) {
  const bris = rec.bris || (rec.bris = carryBris(null));
  if (!Array.isArray(bris.log)) bris.log = [];
  const activity = g.farmActivity && typeof g.farmActivity === "object" ? g.farmActivity : null;
  const inventory = g.inventory && typeof g.inventory === "object" ? g.inventory : null;
  if (!activity || !inventory) return;
  const ctrNow = cookCounterNow(activity, BRISTLE_KEY);
  const invNow = Number(inventory["Pig Bristles"]) || 0;
  const pigsNow = pigSnapshot(g);
  if (bris.known) {
    const traded = Math.floor(ctrNow - bris.ctr);
    if (traded > 0) {
      const gone = pigsNow ? Object.keys(bris.pigs || {}).filter(id => !pigsNow[id]).slice(0, traded) : [];
      const picks = [];
      gone.forEach(id => {
        let r = null;
        try {
          r = pigBristlesFor(bris.pigs[id]);
        } catch (e) {
          r = null;
        }
        if (r && r.amount > 0) picks.push(r);
      });
      const est = picks.reduce((sum, r) => sum + r.amount, 0);
      const gained = invNow - bris.inv;
      const unseen = traded - picks.length;
      const total = unseen > 0 && gained > est + .01 ? gained : est;
      if (total > 1e-9) {
        const gapScale = fresh && prevSyncAt && prevSyncAt < start ? Math.min(1, Math.max(0, (now - start) / (now - prevSyncAt))) : 1;
        bris.a += total * gapScale;
        bris.c += Math.round(traded * gapScale);
        picks.forEach(r => bris.log.push({
          t: now,
          a: r.amount,
          l: r.level
        }));
        const extra = Math.round((total - est) * 100) / 100;
        if (extra > .009) bris.log.push({
          t: now,
          a: extra,
          e: 1
        });
        if (bris.log.length > COOK_LOG_CAP) bris.log.splice(0, bris.log.length - COOK_LOG_CAP);
      }
    }
  }
  bris.ctr = ctrNow;
  bris.inv = invNow;
  if (pigsNow) bris.pigs = pigsNow;
  bris.known = true;
}

const CAVE_BEETLE_RE = /^(?:(?:Green|Blue|Pink|Amber) )?Beetle$/;

function cookCounterNow(activity, key) {
  const v = activity ? Number(activity[key]) : NaN;
  return Number.isFinite(v) && v > 0 ? v : 0;
}

const COOK_LOG_CAP = 200;

const COOK_NO_ESTIMATE = {
  "Fermentation Rack": true,
  "Aging Shed": true,
  "Compost Bin": true,
  "Turbo Composter": true,
  "Premium Composter": true
};

const COOK_ESTIMATE_CAP = 500;

var iconProvider;

export function dailyHarvestSetIconProvider(fn) {
  iconProvider = typeof fn === "function" ? fn : null;
}

var toolProvider;

export function dailyHarvestSetToolProvider(fn) {
  toolProvider = typeof fn === "function" ? fn : null;
}

const TOOL_GROUPS = {
  Wood: true,
  Stone: true,
  Iron: true,
  Gold: true,
  Crimstone: true,
  Oil: true
};

const TIER_TOOL_MULT = {
  "Ancient Tree": 4,
  "Sacred Tree": 16,
  "Fused Stone Rock": 4,
  "Reinforced Stone Rock": 16,
  "Refined Iron Rock": 4,
  "Tempered Iron Rock": 16,
  "Pure Gold Rock": 4,
  "Prime Gold Rock": 16
};

function actKeyToolMult(key) {
  return TIER_TOOL_MULT[String(key).replace(/ (Chopped|Mined)$/, "")] || 1;
}

export function dailyHarvestNodeToolMult(node) {
  if (!node || typeof node !== "object") return 1;
  if (typeof node.name === "string" && TIER_TOOL_MULT[node.name]) return TIER_TOOL_MULT[node.name];
  const m = Number(node.multiplier);
  return Number.isFinite(m) && m >= 1 ? m : 1;
}

function toolInfoFor(groupKey) {
  if (!toolProvider || !TOOL_GROUPS[groupKey]) return null;
  try {
    const info = toolProvider(groupKey);
    if (!info || !info.tool) return null;
    const factor = typeof info.factor === "number" && isFinite(info.factor) && info.factor >= 0 ? info.factor : 1;
    return {
      tool: info.tool,
      factor: factor,
      icon: info.icon || ""
    };
  } catch (e) {
    return null;
  }
}

function roundTools(v) {
  return Math.round(v * 100) / 100;
}

function fmtTools(v) {
  return Number.isInteger(v) ? String(v) : v.toFixed(2);
}

const COMPOSTER_BUILDINGS = {
  "Compost Bin": true,
  "Turbo Composter": true,
  "Premium Composter": true
};

function addCookEntry(cook, building, name, amount, count, price, fee, at, estimated) {
  const t = cook.totals[name] || (cook.totals[name] = {
    a: 0,
    c: 0,
    p: 0,
    f: 0
  });
  if (COMPOSTER_BUILDINGS[building]) t.k = "composter";
  t.a += amount;
  t.c += count;
  if (price > 0) {
    t.p = price;
    t.f = fee || 0;
  }
  const bld = cook.bld[building] || (cook.bld[building] = {
    est: false,
    items: {}
  });
  const it = bld.items[name] || (bld.items[name] = {
    a: 0,
    c: 0,
    p: 0,
    f: 0,
    log: []
  });
  it.a += amount;
  it.c += count;
  if (price > 0) {
    it.p = price;
    it.f = fee || 0;
  }
  const entry = {
    t: at,
    a: amount,
    n: count
  };
  if (estimated) entry.e = 1;
  it.log.push(entry);
  if (it.log.length > COOK_LOG_CAP) it.log.splice(0, it.log.length - COOK_LOG_CAP);
  if (estimated) bld.est = true;
}

function trackCooking(g, rec, fresh, now) {
  if (!cookProvider) return;
  let res;
  try {
    res = cookProvider(g);
  } catch (e) {
    return;
  }
  if (!res || !Array.isArray(res.slots) || !Array.isArray(res.present)) return;
  const activity = res.activity && typeof res.activity === "object" ? res.activity : null;
  const cook = rec.cook || (rec.cook = carryCook(null));
  if (!cook.bld || typeof cook.bld !== "object") cook.bld = {};
  if (!cook.hint || typeof cook.hint !== "object") cook.hint = {};
  const start = utcDayStart(now);
  const present = new Set(res.present);
  const cur = {};
  const seen = {};
  res.slots.forEach(sl => {
    if (!sl || !sl.name) return;
    const base = `${sl.building}|${sl.name}|${sl.readyAt}`;
    seen[base] = (seen[base] || 0) + 1;
    const entry = {
      b: sl.building,
      name: sl.name,
      amount: sl.amount,
      readyAt: sl.readyAt,
      price: sl.price || 0,
      fee: sl.feeRate || 0,
      k: Array.isArray(sl.keys) ? sl.keys : []
    };
    if (sl.worm && sl.worm.name) entry.w = {
      name: sl.worm.name,
      ck: sl.worm.counterKey || "",
      price: sl.worm.price || 0,
      fee: sl.worm.feeRate || 0
    };
    cur[`${base}|${seen[base]}`] = entry;
    if (entry.k.length) cook.hint[entry.k.join("|")] = {
      b: entry.b,
      name: entry.name,
      amount: entry.amount,
      price: entry.price,
      fee: entry.fee,
      k: entry.k
    };
  });
  const prevCtr = cook.ctr && typeof cook.ctr === "object" ? cook.ctr : null;
  const budget = {};
  const wormIdx = {};
  const wormRolls = res.worms && typeof res.worms === "object" ? res.worms : {};
  const deltaOf = keys => keys.reduce((sum, k) => sum + Math.max(0, cookCounterNow(activity, k) - prevCtr[k]), 0);
  if (cook.known) {
    const gone = Object.keys(cook.prev).filter(key => !cur[key]).map(key => cook.prev[key]).filter(p => p && present.has(p.b) && typeof p.amount === "number" && p.amount > 0);
    gone.sort((a, b) => (a.readyAt <= now ? 0 : 1) - (b.readyAt <= now ? 0 : 1) || a.readyAt - b.readyAt);
    gone.forEach(p => {
      const keys = Array.isArray(p.k) ? p.k : [];
      const gated = !!(activity && prevCtr && keys.length && keys.every(k => typeof prevCtr[k] === "number"));
      if (gated) {
        const id = keys.join("|");
        if (budget[id] === undefined) budget[id] = deltaOf(keys);
        if (budget[id] <= 0) return;
        budget[id] -= 1;
      } else if (!(p.readyAt <= now)) {
        return;
      }
      const carriedOver = fresh && p.readyAt < start;
      addCookEntry(cook, p.b, p.name, p.amount, 1, p.price, p.fee, now, carriedOver);
      const worm = p.w && p.w.name ? p.w : null;
      const rollFn = worm ? wormRolls[p.b] : null;
      if (rollFn && gated && worm.ck && typeof prevCtr[worm.ck] === "number") {
        const wid = worm.ck;
        const idx = wormIdx[wid] || 0;
        wormIdx[wid] = idx + 1;
        const wormAmount = Number(rollFn(prevCtr[wid] + idx));
        if (wormAmount > 0) addCookEntry(cook, p.b, worm.name, wormAmount, 1, worm.price || 0, worm.fee || 0, now, carriedOver);
      }
    });
    if (!fresh && activity && prevCtr) {
      Object.keys(cook.hint).forEach(id => {
        const h = cook.hint[id];
        if (!h || COOK_NO_ESTIMATE[h.b] || !present.has(h.b) || !(h.amount > 0)) return;
        const keys = Array.isArray(h.k) ? h.k : [];
        if (!keys.length || !keys.every(k => typeof prevCtr[k] === "number")) return;
        const left = Math.min(Math.floor(budget[id] !== undefined ? budget[id] : deltaOf(keys)), COOK_ESTIMATE_CAP);
        if (left > 0) addCookEntry(cook, h.b, h.name, h.amount * left, left, h.price, h.fee, now, true);
      });
    }
  }
  const instant = Array.isArray(res.instant) ? res.instant : [];
  if (cook.known && activity && prevCtr) {
    const prevSync = rec.syncAt || 0;
    const gapScale = fresh && prevSync && prevSync < start ? Math.min(1, Math.max(0, (now - start) / (now - prevSync))) : 1;
    instant.forEach(e => {
      if (!e || !e.key || typeof e.amountAt !== "function" || typeof prevCtr[e.key] !== "number") return;
      const from = Math.floor(prevCtr[e.key]);
      const total = Math.min(Math.floor(cookCounterNow(activity, e.key)) - from, COOK_ESTIMATE_CAP);
      const scaled = fresh ? Math.round(total * gapScale) : total;
      const to = from + Math.max(0, scaled);
      for (let n = from; n < to; n++) {
        const amount = e.amountAt(n);
        if (!(amount > 0)) continue;
        addCookEntry(cook, e.building || "Kitchen", e.name, amount, 1, e.price, e.feeRate || 0, now, fresh);
      }
    });
  }
  const kept = {};
  const ctr = {};
  Object.keys(cook.prev).forEach(key => {
    const p = cook.prev[key];
    if (!p || present.has(p.b)) return;
    kept[key] = p;
    (Array.isArray(p.k) ? p.k : []).concat(p.w && p.w.ck ? [ p.w.ck ] : []).forEach(k => {
      if (prevCtr && typeof prevCtr[k] === "number") ctr[k] = prevCtr[k];
    });
  });
  if (activity) Object.keys(cur).forEach(key => {
    cur[key].k.concat(cur[key].w && cur[key].w.ck ? [ cur[key].w.ck ] : []).forEach(k => {
      ctr[k] = cookCounterNow(activity, k);
    });
  });
  if (activity) instant.forEach(e => {
    if (e && e.key) ctr[e.key] = cookCounterNow(activity, e.key);
  });
  Object.keys(cook.hint).forEach(id => {
    const h = cook.hint[id];
    if (!h) return;
    (Array.isArray(h.k) ? h.k : []).forEach(k => {
      if (activity && present.has(h.b)) ctr[k] = cookCounterNow(activity, k); else if (ctr[k] === undefined && prevCtr && typeof prevCtr[k] === "number") ctr[k] = prevCtr[k];
    });
  });
  cook.prev = Object.assign(kept, cur);
  cook.ctr = ctr;
  cook.known = true;
}

const TREE_BASE_RECOVERY_MS = 7200 * 1e3;

const TREE_CHARGE_RANKS = [ .9, .875, .85 ];

function treePermanentShiftMs(g) {
  let mult = 1;
  const col = g && g.collectibles && typeof g.collectibles === "object" ? g.collectibles : {};
  const placed = name => Array.isArray(col[name]) && col[name].some(c => c && c.coordinates);
  if (placed("Apprentice Beaver") || placed("Foreman Beaver")) mult *= .5;
  const skills = g && g.bumpkin && g.bumpkin.skills ? g.bumpkin.skills : {};
  const lvl = Number(skills["Tree Charge"]) || 0;
  if (lvl > 0) mult *= TREE_CHARGE_RANKS[Math.min(lvl, TREE_CHARGE_RANKS.length) - 1];
  return Math.round(TREE_BASE_RECOVERY_MS * (1 - mult));
}

const TREE_USE_BOOSTS = [ "Tree Charge", "Tree Turnaround", "Tough Tree", "Lumberjack's Extra", "Apprentice Beaver", "Foreman Beaver", "Super Totem", "Time Warp Totem", "Timber Hourglass", "Badger Shrine" ];

const WOOD_BATCH_MS = 5 * 6e4;

let woodShiftMs = 0;

let woodLowerBound = 0;

let woodAnchor = 0;

let woodBatchMin = 0;

const OIL_USE_BOOSTS = [ "Oil Extraction", "Oil Gallon", "Oil Can", "Oil Overalls", "Battle Fish", "Knight Chicken", "Stag Shrine", "Dev Wrench", "Oil Be Back", "Infernal Drill" ];

const OIL_BASE_RECOVERY_MS = 20 * 3600 * 1e3;

let oilAnchor = 0;

let oilBatchMin = 0;

function latestTreeUse(g, from, now, names) {
  const used = g && g.boostsUsedAt && typeof g.boostsUsedAt === "object" ? g.boostsUsedAt : {};
  let best = 0;
  (names || TREE_USE_BOOSTS).forEach(name => {
    const t = used[name];
    if (typeof t === "number" && t >= from && t <= now && t > best) best = t;
  });
  return best;
}

function realStamp(groupKey, node, now) {
  const ts = node ? node.ts : 0;
  if (!ts) return ts;
  if (node.shift > 0) return Math.min(now, ts + node.shift);
  if (groupKey === "Oil" && node.legacy) {
    if (oilAnchor && ts >= oilBatchMin && oilAnchor >= ts && oilAnchor <= ts + OIL_BASE_RECOVERY_MS) return Math.min(now, oilAnchor);
    return ts;
  }
  if (groupKey !== "Wood" || !node.legacy) return ts;
  if (woodAnchor && ts >= woodBatchMin && woodAnchor >= ts && woodAnchor <= ts + TREE_BASE_RECOVERY_MS) return Math.min(now, woodAnchor);
  const lower = Math.min(now, Math.max(ts, woodLowerBound));
  return Math.min(now, Math.max(lower, ts + woodShiftMs));
}

export function dailyHarvestSetResolver(fn) {
  pendResolver = typeof fn === "function" ? fn : null;
}

var animalYieldProvider;

export function dailyHarvestSetAnimalYieldProvider(fn) {
  animalYieldProvider = typeof fn === "function" ? fn : null;
}

function claimedAnimalYield(groupKey, current, before) {
  if (!animalYieldProvider || !current) return null;
  const state = typeof current.s === "string" ? current.s : "";
  let xp = null;
  if (state === "idle" || state === "sick") xp = current.x;
  else if (before && before.s === "ready") xp = before.x;
  if (typeof xp !== "number" || !isFinite(xp)) return null;
  const buff = before && typeof before.s === "string" ? before.b || "" : current.b || "";
  try {
    return animalYieldProvider(groupKey, xp, buff);
  } catch (e) {
    return null;
  }
}

function pickActivity(fa) {
  const out = {};
  if (!fa || typeof fa !== "object") return out;
  Object.keys(fa).forEach(k => {
    if (k !== "Tree Chopped" && ACT_KEY_RE.test(k) && typeof fa[k] === "number") out[k] = fa[k];
  });
  return out;
}

function oilAmountOf(g, id) {
  const reserve = g.oilReserves && g.oilReserves[id];
  const amount = reserve && reserve.oil && reserve.oil.amount;
  return typeof amount === "number" && isFinite(amount) && amount > 0 ? amount : null;
}

const FLOW_KEYS = new Set([
  "Treasure Dug",
  "Digging Reward Collected",
  "Pirate Chest Opened",
  "Daily Reward Collected",
  "Gift Giver Reward Opened",
  "VIP Chest Opened",
  "VIP Gift Claimed",
  "Airdrop Reward Claimed",
  "Streamer Hat Reward Claimed",
  "Minigame Prize Claimed",
  "Faction Prize Claimed",
  "Raffle Won",
  "Coins Order Delivered",
  "FLOWER Order Delivered",
  "Ticket Order Delivered",
  "Marketplace Offer Claimed",
  "Marketplace Listing Created",
  "Marketplace Listing Cancelled",
  "Marketplace Bulk Listings Cancelled",
  "Marketplace Offer Made",
  "Marketplace Offer Cancelled",
  "Marketplace Bulk Offers Cancelled",
  "Trades Cleared",
  "Chore Skipped",
  "Shiny Feather Collected",
  "Acorn Fetched",
  "Dewberry Fetched",
  "Heart leaf Fetched",
  "Ribbon Fetched",
  "Fossil Shell Fetched",
  "Chewed Bone Fetched",
  "Crabs and Traps Points Earned",
  "Salt Awakening free Milestone Claimed",
  "Salt Awakening premium Milestone Claimed",
  "Ascension Age free Milestone Claimed",
  "Ascension Age premium Milestone Claimed",
  "Crabs and Traps free Milestone Claimed",
  "Crabs and Traps premium Milestone Claimed"
]);

const FRUIT_HARVEST_RE = /^(Apple|Blueberry|Orange|Banana|Tomato|Lemon|Grape|Duskberry|Lunara|Celestine|Olive|Crystal Leaf) Harvested$/;

const GROUP_FLOW_RE = /^(Wood|Stone|Iron|Gold) (Bought|Sold|Delivered|Fetched|Collected|Burned|Exchanged)$/;

function isFlowKey(key) {
  return FLOW_KEYS.has(key) || FRUIT_HARVEST_RE.test(key) || GROUP_FLOW_RE.test(key);
}

function pickFlow(fa) {
  const out = {};
  if (!fa || typeof fa !== "object") return out;
  Object.keys(fa).forEach(k => {
    if (isFlowKey(k) && typeof fa[k] === "number") out[k] = fa[k];
  });
  return out;
}

function flowAffects(groupKey, key) {
  if (FRUIT_HARVEST_RE.test(key)) return groupKey === "Wood";
  const m = GROUP_FLOW_RE.exec(key);
  if (m) return m[1] === groupKey;
  return true;
}

function hasOutsideFlow(groupKey, flowPrev, flowNow) {
  const known = Object.keys(flowPrev).length > 0;
  if (!known) return false;
  return Object.keys(flowNow).some(k => {
    if (!flowAffects(groupKey, k)) return false;
    const before = typeof flowPrev[k] === "number" ? flowPrev[k] : 0;
    return flowNow[k] > before;
  });
}

const LOG_CAP = 60;

const POWER_KINDS = {
  "Tree Blitz": "wood",
  "Grease Lightning": "oil",
  "Instant Growth": "crop",
  "Barnyard Rouse": "animal",
  "Greenhouse Guru": "greenhouse",
  "Petal Blessed": "flower"
};

function kindOfGroup(groupKey) {
  if (groupKey === "Wood") return "wood";
  if (groupKey === "Oil") return "oil";
  return "";
}

const TOOL_BAG_KEYS = {
  Wood: "trees",
  Stone: "stones",
  Iron: "iron",
  Gold: "gold",
  Crimstone: "crimstones",
  Oil: "oilReserves"
};

const NODE_BAGS = [ [ "trees", "Wood", n => n.wood && n.wood.choppedAt ], [ "stones", "Stone", n => n.stone && n.stone.minedAt ], [ "iron", "Iron", n => n.stone && n.stone.minedAt ], [ "gold", "Gold", n => n.stone && n.stone.minedAt ], [ "crimstones", "Crimstone", n => n.stone && n.stone.minedAt ], [ "oilReserves", "Oil", n => n.oil && n.oil.drilledAt ] ];

function isCropMachineActive(g, now) {
  const list = g.buildings && g.buildings["Crop Machine"];
  return Array.isArray(list) && list.some(b => isActiveNode(b, now));
}

function inventoryItemFor(groupKey, kind) {
  if (kind === "animal" || groupKey === "Honey") return null;
  return groupKey;
}

function collectGroups(g, now) {
  const groups = {};
  const cropMachine = isCropMachineActive(g, now);
  const add = (groupKey, mode, id, ts, key, noCounter, val, kind, legacy, shift) => {
    const grp = groups[groupKey] || (groups[groupKey] = {
      mode: mode,
      kind: kind || kindOfGroup(groupKey),
      noCounter: !!noCounter,
      nodes: {}
    });
    grp.nodes[id] = {
      ts: ts,
      key: key,
      val: val,
      legacy: !!legacy,
      shift: typeof shift === "number" && shift > 0 ? shift : 0
    };
  };
  NODE_BAGS.forEach(([bagKey, groupKey, getTs]) => {
    const bag = g[bagKey];
    if (!bag || typeof bag !== "object") return;
    Object.entries(bag).forEach(([id, node]) => {
      if (!isActiveNode(node, now)) return;
      const ts = numTs(getTs(node));
      const legacy = groupKey === "Wood" && !(node.wood && node.wood.baseDurationMs !== undefined) || groupKey === "Oil" && !(node.oil && node.oil.baseDurationMs !== undefined);
      const rock = node.stone && node.stone.baseDurationMs === undefined ? node.stone.boostedTime : 0;
      add(groupKey, "ts", id, ts, String(ts), undefined, undefined, undefined, legacy, rock);
    });
  });
  if (g.crops && typeof g.crops === "object") {
    Object.entries(g.crops).forEach(([id, plot]) => {
      if (!isActiveNode(plot, now)) return;
      const crop = plot.crop;
      if (!crop || !crop.name) return;
      add(crop.name, "key", id, numTs(crop.plantedAt), crop.id ? String(crop.id) : String(numTs(crop.plantedAt)), cropMachine, undefined, "crop", false, crop.baseDurationMs === undefined ? crop.boostedTime : 0);
    });
  }
  if (g.greenhouse && g.greenhouse.pots && typeof g.greenhouse.pots === "object") {
    Object.entries(g.greenhouse.pots).forEach(([id, pot]) => {
      const plant = pot && pot.plant;
      if (!plant || !plant.name) return;
      add(plant.name, "key", id, 0, plant.name, false, undefined, "greenhouse");
    });
  }
  if (g.flowers && g.flowers.flowerBeds && typeof g.flowers.flowerBeds === "object") {
    Object.entries(g.flowers.flowerBeds).forEach(([id, bed]) => {
      const flower = bed && bed.flower;
      if (!flower || !flower.name) return;
      add(flower.name, "key", id, 0, flower.name, false, undefined, "flower");
    });
  }
  if (g.fruitPatches && typeof g.fruitPatches === "object") {
    Object.entries(g.fruitPatches).forEach(([id, patch]) => {
      if (!isActiveNode(patch, now)) return;
      const fruit = patch.fruit;
      if (!fruit || !fruit.name) return;
      add(fruit.name, "key", id, numTs(fruit.harvestedAt), `${numTs(fruit.plantedAt)}|${numTs(fruit.harvestedAt)}`, undefined, undefined, "fruit", false, fruit.baseDurationMs === undefined && fruit.harvestedAt ? fruit.boostedTime : 0);
    });
  }
  if (g.beehives && typeof g.beehives === "object") {
    Object.entries(g.beehives).forEach(([id, hive]) => {
      if (!hive || !hive.honey || typeof hive.honey.produced !== "number") return;
      add("Honey", "honey", id, numTs(hive.honey.updatedAt), String(hive.honey.produced), false, hive.honey.produced);
    });
  }
  [ "henHouse", "barn", "pigpen" ].forEach(buildingKey => {
    const animals = g[buildingKey] && g[buildingKey].animals;
    if (!animals || typeof animals !== "object") return;
    Object.entries(animals).forEach(([id, animal]) => {
      if (!animal || !animal.type) return;
      const ts = numTs(animal.asleepAt);
      add(animal.type, "ts", id, ts, String(ts), false, undefined, "animal");
      const node = groups[animal.type].nodes[id];
      const xp = Number(animal.experience);
      if (isFinite(xp)) node.x = xp;
      if (typeof animal.state === "string") node.s = animal.state;
      const fb = animal.feedBuff;
      if (fb && typeof fb === "object" && fb.name && !(fb.harvestsRemaining <= 0)) node.b = fb.name;
    });
  });
  return groups;
}

const COUNTER_KEYS = {
  Crimstone: "Crimstone Mined",
  Oil: "Oil Drilled",
  Chicken: "Egg Collected",
  Cow: "Milk Collected",
  Sheep: "Wool Collected"
};

const COUNTER_PATTERNS = {
  Wood: k => /Tree Chopped$/.test(k) && k !== "Tree Chopped",
  Stone: k => /Stone Rock Mined$/.test(k),
  Iron: k => /Iron Rock Mined$/.test(k),
  Gold: k => /Gold Rock Mined$/.test(k)
};

function counterFor(g, groupKey, noCounter) {
  const fa = g.farmActivity;
  if (noCounter || !fa || typeof fa !== "object") return null;
  if (COUNTER_PATTERNS[groupKey]) {
    let sum = 0;
    let found = false;
    Object.keys(fa).forEach(k => {
      if (COUNTER_PATTERNS[groupKey](k)) {
        sum += Number(fa[k]) || 0;
        found = true;
      }
    });
    return found ? sum : 0;
  }
  const key = COUNTER_KEYS[groupKey] || `${groupKey} Harvested`;
  return typeof fa[key] === "number" ? fa[key] : 0;
}

function roundsFromStats(st) {
  const need = Math.max(1, Math.ceil(st.total * ROUND_THRESHOLD));
  const counts = Object.values(st.counts).sort((a, b) => b - a);
  const rounds = counts.length >= need ? counts[need - 1] : 0;
  const nextProgress = counts.filter(c => c > rounds).length;
  return {
    need: need,
    rounds: rounds,
    nextProgress: nextProgress
  };
}

function trackCoins(g, rec, fresh, prevSyncAt, start, now) {
  const fa = g.farmActivity && typeof g.farmActivity === "object" ? g.farmActivity : null;
  const spentNow = fa ? Number(fa["Coins Spent"]) : NaN;
  const earnedNow = fa ? Number(fa["Coins Earned"]) : NaN;
  const coin = rec.coin && typeof rec.coin === "object" ? rec.coin : {
    s: 0,
    e: 0,
    est: false
  };
  const cc = rec.cc && typeof rec.cc === "object" ? rec.cc : {};
  const scale = fresh && prevSyncAt && prevSyncAt < start ? Math.min(1, Math.max(0, (now - start) / (now - prevSyncAt))) : 1;
  const spentDelta = Number.isFinite(spentNow) && typeof cc.s === "number" && spentNow > cc.s ? spentNow - cc.s : 0;
  const earnedDelta = Number.isFinite(earnedNow) && typeof cc.e === "number" && earnedNow > cc.e ? earnedNow - cc.e : 0;
  if (spentDelta > 0) {
    coin.s += spentDelta * scale;
    if (scale < 1) coin.est = true;
  }
  if (earnedDelta > 0) {
    coin.e += earnedDelta * scale;
    if (scale < 1) coin.est = true;
  }
  const balance = Number(g.coins);
  const prevBalance = typeof cc.b === "number" ? cc.b : !fresh && typeof coin.b === "number" ? coin.b : NaN;
  if (Number.isFinite(balance) && Number.isFinite(prevBalance)) {
    const untracked = balance - prevBalance - earnedDelta + spentDelta;
    if (untracked > 0.005) {
      coin.e += untracked * scale;
      if (scale < 1) coin.est = true;
    } else if (untracked < -0.005) {
      coin.s += -untracked * scale;
      if (scale < 1) coin.est = true;
    }
  }
  if (Number.isFinite(balance)) coin.b = balance;
  rec.coin = coin;
  rec.cc = {
    s: Number.isFinite(spentNow) ? spentNow : cc.s,
    e: Number.isFinite(earnedNow) ? earnedNow : cc.e,
    b: Number.isFinite(balance) ? balance : cc.b
  };
}

export function dailyHarvestTrack(g, farmId) {
  if (!g || typeof g !== "object") return;
  const now = Date.now();
  const today = utcDay(now);
  const start = utcDayStart(now);
  const store = freshStore();
  const fid = String(farmId || store.__last || "");
  if (!fid) return;
  store.__last = fid;
  pruneStore(store);
  const old = store[fid];
  let rec = old;
  const fresh = !rec || rec.day !== today;
  if (fresh) rec = {
    day: today,
    prev: {},
    stats: {},
    counters: old && old.counters ? old.counters : {},
    inv: old && old.inv ? old.inv : {},
    act: old && old.act ? old.act : {},
    flow: old && old.flow ? old.flow : {},
    power: old && old.power ? old.power : {},
    amts: old && old.amts ? old.amts : {},
    ym: old && old.ym ? old.ym : {},
    cc: old && old.cc ? old.cc : {},
    coin: {
      s: 0,
      e: 0,
      est: false
    },
    syncAt: old && old.syncAt ? old.syncAt : 0,
    cook: carryCook(old && old.cook),
    bris: carryBris(old && old.bris)
  };
  const prevSyncAt = rec.syncAt || 0;
  woodShiftMs = treePermanentShiftMs(g);
  woodLowerBound = Math.max(prevSyncAt, start);
  const invPrev = rec.inv || {};
  const actPrev = rec.act || {};
  const actNow = pickActivity(g.farmActivity);
  const flowPrev = rec.flow || {};
  const flowNow = pickFlow(g.farmActivity);
  const invNowMap = {};
  const inventory = g.inventory && typeof g.inventory === "object" ? g.inventory : null;
  const powerNow = g.bumpkin && g.bumpkin.previousPowerUseAt && typeof g.bumpkin.previousPowerUseAt === "object" ? g.bumpkin.previousPowerUseAt : {};
  const knownPower = rec.power || {};
  const skillTimes = {};
  Object.keys(POWER_KINDS).forEach(skill => {
    const at = powerNow[skill];
    if (typeof at !== "number" || !prevSyncAt || at <= prevSyncAt || at <= (knownPower[skill] || 0)) return;
    const kind = POWER_KINDS[skill];
    skillTimes[kind] = Math.max(skillTimes[kind] || 0, at);
  });
  const groups = collectGroups(g, now);
  woodAnchor = latestTreeUse(g, woodLowerBound, now);
  woodBatchMin = 0;
  if (groups.Wood) {
    const legacyTs = Object.values(groups.Wood.nodes).filter(n => n.legacy && n.ts).map(n => n.ts);
    if (legacyTs.length) woodBatchMin = Math.max(...legacyTs) - WOOD_BATCH_MS;
  }
  oilAnchor = latestTreeUse(g, Math.max(prevSyncAt, start), now, OIL_USE_BOOSTS);
  oilBatchMin = 0;
  if (groups.Oil) {
    const oilTs = Object.values(groups.Oil.nodes).filter(n => n.legacy && n.ts).map(n => n.ts);
    if (oilTs.length) oilBatchMin = Math.max(...oilTs) - WOOD_BATCH_MS;
  }
  const priorGroups = fresh ? old && old.prev ? old.prev : {} : rec.prev;
  const keys = new Set([ ...Object.keys(groups), ...Object.keys(rec.prev), ...Object.keys(priorGroups) ]);
  keys.forEach(groupKey => {
    const invItem = inventoryItemFor(groupKey, groups[groupKey] ? groups[groupKey].kind : "");
    if (invItem && inventory) invNowMap[invItem] = Number(inventory[invItem]) || 0;
    const grp = groups[groupKey] || {
      mode: priorGroups[groupKey] ? priorGroups[groupKey].mode : "ts",
      noCounter: priorGroups[groupKey] ? !!priorGroups[groupKey].noCounter : false,
      kind: priorGroups[groupKey] ? priorGroups[groupKey].kind : undefined,
      nodes: {}
    };
    const ids = Object.keys(grp.nodes);
    const prev = fresh ? null : rec.prev[groupKey] || null;
    const carried = fresh && priorGroups[groupKey] ? priorGroups[groupKey] : null;
    let st = rec.stats[groupKey];
    if (!st) st = rec.stats[groupKey] = {
      total: ids.length,
      counts: {},
      lastAt: 0,
      est: false
    };
    if (grp.kind) st.kind = grp.kind;
    st.total = Math.max(st.total, ids.length);
    const cNow = counterFor(g, groupKey, grp.noCounter);
    const cPrev = typeof rec.counters[groupKey] === "number" ? rec.counters[groupKey] : null;
    if (cNow !== null) rec.counters[groupKey] = cNow;
    const events = [];
    if (fresh) {
      const honeyMoved = grp.mode !== "honey" || cNow !== null && cPrev !== null && cNow > cPrev;
      ids.forEach(id => {
        if (!honeyMoved) return;
        const node = grp.nodes[id];
        if (node.ts >= start) {
          events.push(id);
          return;
        }
        const was = carried && carried.mode === "ts" && carried.nodes[id] ? carried.nodes[id] : null;
        if (grp.mode === "ts" && was && node.ts > was.ts && (!(node.shift > 0) || realStamp(groupKey, node, now) >= start)) events.push(id);
      });
      if (carried && grp.mode === "key" && carried.mode === "key") {
        Object.keys(carried.nodes).forEach(id => {
          if (events.includes(id)) return;
          const c = grp.nodes[id];
          const pk = String(carried.nodes[id].key);
          if (!c || c.key !== pk && !pk.startsWith(`${c.key}:`)) events.push(id);
        });
      }
    } else if (prev) {
      if (grp.mode === "ts") {
        ids.forEach(id => {
          const p = prev.nodes[id];
          if (p && grp.nodes[id].ts > p.ts) events.push(id);
        });
      } else if (grp.mode === "honey") {
        ids.forEach(id => {
          const p = prev.nodes[id];
          if (p && typeof p.val === "number" && grp.nodes[id].val < p.val - 1e-6) events.push(id);
        });
      } else {
        Object.keys(prev.nodes).forEach(id => {
          const c = grp.nodes[id];
          if (!c || c.key !== prev.nodes[id].key && !String(prev.nodes[id].key).startsWith(`${c.key}:`)) events.push(id);
        });
      }
    }
    const skillTime = grp.kind ? skillTimes[grp.kind] || 0 : 0;
    const gapScale = fresh && prevSyncAt && prevSyncAt < start && skillTime < start ? Math.min(1, Math.max(0, (now - start) / (now - prevSyncAt))) : 1;
    let hiddenOnly = false;
    if (!events.length) {
      const gain = grp.mode !== "honey" && skillTime && cNow !== null && cPrev !== null && cNow > cPrev ? Math.round((cNow - cPrev) * gapScale) : 0;
      if (!gain) return;
      hiddenOnly = true;
      ids.forEach(id => events.push(id));
    }
    let extras = 0;
    let estimated = false;
    if (hiddenOnly) {
      extras = Math.round((cNow - cPrev) * gapScale);
      estimated = true;
    } else if (grp.mode === "honey") {
      estimated = fresh;
    } else if (cNow !== null && cPrev !== null && cNow >= cPrev) {
      let yesterday = 0;
      if (fresh && prevSyncAt && prevSyncAt < start) {
        ids.forEach(id => {
          const ts = grp.nodes[id].ts;
          if (ts > prevSyncAt && ts < start) yesterday += 1;
        });
      }
      extras = Math.max(0, cNow - cPrev - events.length - yesterday);
      if (fresh && prevSyncAt && prevSyncAt < start && extras > 0) {
        extras = Math.round(extras * gapScale);
      }
      if (extras > 0) estimated = true;
    } else if (fresh) {
      estimated = true;
    }
    const before = roundsFromStats(st).rounds;
    const sorted = events.slice().sort();
    const per = Math.floor(extras / sorted.length);
    const rem = extras % sorted.length;
    const ref = rec.ym && rec.ym[groupKey] ? rec.ym[groupKey] : null;
    const snapMem = metaFarm === fid && yieldMeta[groupKey] && yieldMeta[groupKey].nodes ? yieldMeta[groupKey].nodes : null;
    const snap = snapMem || (ref && ref.nodes) || null;
    const buckets = {};
    const toolInfo = toolInfoFor(groupKey);
    const toolBag = toolInfo ? g[TOOL_BAG_KEYS[groupKey]] : null;
    const nodeToolMult = id => toolBag && toolBag[id] ? dailyHarvestNodeToolMult(toolBag[id]) : 1;
    let avgToolMult = 1;
    let dTools = 0;
    if (toolInfo) {
      let dChops = 0;
      if (COUNTER_PATTERNS[groupKey]) {
        Object.keys(actNow).forEach(k => {
          if (!COUNTER_PATTERNS[groupKey](k)) return;
          const d = Math.max(0, actNow[k] - (typeof actPrev[k] === "number" ? actPrev[k] : actNow[k]));
          dChops += d;
          dTools += d * actKeyToolMult(k);
        });
      }
      if (dChops > 0) {
        avgToolMult = dTools / dChops;
      } else if (sorted.length) {
        avgToolMult = sorted.reduce((sum, id) => sum + nodeToolMult(id), 0) / sorted.length;
      }
      st.tool = toolInfo.tool;
    }
    sorted.forEach((id, i) => {
      const inc = (hiddenOnly ? 0 : 1) + per + (i < rem ? 1 : 0);
      st.counts[id] = (st.counts[id] || 0) + inc;
      if (hiddenOnly) return;
      const ts = grp.nodes[id] ? grp.nodes[id].ts : 0;
      const rs = ts ? realStamp(groupKey, grp.nodes[id], now) : 0;
      const t = rs && rs >= start ? rs : now;
      const bk = Math.floor(t / 6e4);
      const b = buckets[bk] || (buckets[bk] = {
        t: t,
        n: 0,
        y: 0,
        miss: false,
        tl: 0,
        ids: [],
        p: null
      });
      b.t = Math.max(b.t, t);
      b.n += 1;
      b.tl += nodeToolMult(id);
      b.ids.push(id);
      if (grp.kind === "animal" && animalYieldProvider) {
        const priorNode = prev && prev.nodes ? prev.nodes[id] : carried && carried.nodes ? carried.nodes[id] : null;
        const real = claimedAnimalYield(groupKey, grp.nodes[id], priorNode);
        if (real && typeof real.total === "number" && real.parts) {
          b.y += real.total;
          b.p = b.p || {};
          Object.keys(real.parts).forEach(name => {
            b.p[name] = (b.p[name] || 0) + real.parts[name];
          });
          return;
        }
        b.miss = true;
        return;
      }
      const known = rec.amts ? rec.amts[id] : null;
      const prevAmt = typeof known === "number" && known > 0 ? known : null;
      const oilAmt = groupKey === "Oil" ? prevAmt !== null ? prevAmt : oilAmountOf(g, id) : null;
      if (oilAmt !== null) b.y += oilAmt; else if (snap && typeof snap[id] === "number") b.y += snap[id]; else b.miss = true;
    });
    const honeyTotal = grp.mode === "honey" && cNow !== null && cPrev !== null && cNow > cPrev ? cNow - cPrev : null;
    const resolvable = RESOLVABLE_GROUPS[groupKey] && grp.mode === "ts" && !hiddenOnly;
    const entries = Object.values(buckets).sort((a, b) => a.t - b.t).map(b => {
      const entry = {
        t: b.t,
        n: b.n,
        y: b.miss ? null : b.y
      };
      if (!b.miss && b.p) entry.p = b.p;
      if (toolInfo) entry.tl = roundTools(b.tl * toolInfo.factor);
      if (resolvable) entry.ids = b.ids;
      return entry;
    });
    let pendId = null;
    if (resolvable && entries.length) {
      const pid = String(now);
      pendId = pid;
      const ordered = sorted.slice().sort((a, b) => grp.nodes[a].ts - grp.nodes[b].ts || (a < b ? -1 : 1));
      st.pend = st.pend || {};
      st.pend[pid] = {
        ids: ordered,
        prev: Object.assign({}, actPrev),
        now: Object.assign({}, actNow)
      };
      entries.forEach(e => {
        e.pid = pid;
      });
    }
    if (extras > 0 && grp.mode !== "honey") {
      const snapVals = snap ? Object.values(snap).filter(v => typeof v === "number") : [];
      const mean = snapVals.length ? snapVals.reduce((a, b) => a + b, 0) / snapVals.length : 0;
      const lastVisible = entries.length ? entries[entries.length - 1].t : now;
      const extraEntry = {
        t: skillTime || lastVisible,
        n: extras,
        y: mean ? mean * extras : null
      };
      if (toolInfo) {
        const bucketRaw = Object.values(buckets).reduce((sum, b) => sum + b.tl, 0);
        const exactSpan = !fresh && !hiddenOnly && dTools > 0;
        const rawExtra = exactSpan ? Math.max(0, dTools - bucketRaw) : extras * avgToolMult;
        extraEntry.tl = roundTools(rawExtra * toolInfo.factor);
      }
      if (pendId) extraEntry.xpid = pendId;
      entries.push(extraEntry);
    }
    const nSum = entries.reduce((sum, e) => sum + e.n, 0) || 1;
    entries.forEach(e => {
      if (honeyTotal !== null) e.y = honeyTotal * e.n / nSum;
    });
    if (honeyTotal === null && ref && ref.per > 0) entries.forEach(e => {
      if (e.y !== null && e.y !== undefined) return;
      if (Array.isArray(ref.products) && ref.products.length > 1) {
        e.p = {};
        let sum = 0;
        ref.products.forEach(pr => {
          const v = e.n * pr.per;
          e.p[pr.name] = v;
          sum += v;
        });
        e.y = sum;
      } else {
        e.y = e.n * ref.per;
      }
    });
    const invItemNow = inventoryItemFor(groupKey, grp.kind);
    const invBefore = invItemNow && typeof invPrev[invItemNow] === "number" ? invPrev[invItemNow] : null;
    const invAfter = invItemNow && typeof invNowMap[invItemNow] === "number" ? invNowMap[invItemNow] : null;
    const spanInDay = !(fresh && prevSyncAt && prevSyncAt < start);
    const outsideFlow = hasOutsideFlow(groupKey, flowPrev, flowNow);
    if (honeyTotal === null && groupKey !== "Oil" && invBefore !== null && invAfter !== null && spanInDay && entries.length && !outsideFlow) {
      const gained = invAfter - invBefore;
      if (gained > 1e-9) entries.forEach(e => {
        e.y = gained * e.n / nSum;
      });
    }
    const mergedLog = (st.log || []).concat(entries);
    const overflow = mergedLog.length - LOG_CAP;
    if (overflow > 0) {
      const gone = mergedLog.slice(0, overflow);
      st.dropped = (st.dropped || 0) + gone.reduce((sum, e) => sum + (typeof e.y === "number" ? e.y : 0), 0);
      st.droppedTl = (st.droppedTl || 0) + gone.reduce((sum, e) => sum + (typeof e.tl === "number" ? e.tl : 0), 0);
    }
    st.log = mergedLog.slice(-LOG_CAP);
    if (estimated) st.est = true;
    const after = roundsFromStats(st).rounds;
    if (after > before) {
      const stamps = hiddenOnly ? [ skillTime ] : events.map(id => grp.nodes[id] ? realStamp(groupKey, grp.nodes[id], now) : 0).filter(Boolean);
      st.lastAt = stamps.length ? Math.max(...stamps) : now;
    }
  });
  trackCooking(g, rec, fresh, now);
  trackBristles(g, rec, fresh, now, prevSyncAt, start);
  try {
    if (g.cave && typeof g.cave === "object") collectCaveDugToday(g.cave, fid, now);
  } catch (e) {}
  rec.prev = groups;
  const amtsNow = {};
  Object.keys(g.oilReserves || {}).forEach(id => {
    const a = oilAmountOf(g, id);
    if (a !== null) amtsNow[id] = a;
  });
  rec.amts = amtsNow;
  rec.power = Object.assign({}, knownPower);
  Object.keys(POWER_KINDS).forEach(skill => {
    if (typeof powerNow[skill] === "number") rec.power[skill] = powerNow[skill];
  });
  rec.inv = Object.assign({}, invPrev, invNowMap);
  rec.act = Object.assign({}, actPrev, actNow);
  rec.flow = Object.assign({}, flowPrev, flowNow);
  trackCoins(g, rec, fresh, prevSyncAt, start, now);
  rec.syncAt = now;
  store[fid] = rec;
  saveStore();
}

export function dailyHarvestInfo(groupKey, farmId) {
  const store = freshStore();
  const rec = store[farmId ? String(farmId) : store.__last];
  if (!rec || rec.day !== utcDay(Date.now())) return null;
  const st = rec.stats[groupKey];
  if (!st) return null;
  const r = roundsFromStats(st);
  if (r.rounds < 1) return null;
  return {
    rounds: r.rounds,
    need: r.need,
    total: st.total,
    nextProgress: r.nextProgress,
    lastAt: st.lastAt,
    estimated: !!st.est,
    dropped: typeof st.dropped === "number" ? st.dropped : 0,
    droppedTl: typeof st.droppedTl === "number" ? st.droppedTl : 0,
    log: Array.isArray(st.log) ? st.log : []
  };
}

export function dailyCookingInfo(building, farmId) {
  const store = freshStore();
  const rec = store[farmId ? String(farmId) : store.__last];
  if (!rec || rec.day !== utcDay(Date.now())) return null;
  const bld = rec.cook && rec.cook.bld ? rec.cook.bld[building] : null;
  if (!bld || !bld.items) return null;
  const items = Object.keys(bld.items).filter(name => bld.items[name] && bld.items[name].c > 0).map(name => ({
    name: name,
    item: bld.items[name]
  }));
  if (!items.length) return null;
  items.sort((a, b) => b.item.c - a.item.c || a.name.localeCompare(b.name));
  const lastAt = items.reduce((max, e) => e.item.log.reduce((m, l) => Math.max(m, l.t || 0), max), 0);
  const composter = !!COMPOSTER_BUILDINGS[building];
  return {
    rounds: composter ? items.reduce((max, e) => Math.max(max, e.item.c), 0) : items.reduce((sum, e) => sum + e.item.c, 0),
    estimated: !!bld.est,
    lastAt: lastAt,
    items: items
  };
}

function resolvePending(st, groupKey) {
  if (!st.pend || !pendResolver) return false;
  let changed = false;
  Object.keys(st.pend).forEach(pid => {
    let resolved;
    try {
      resolved = pendResolver(groupKey, st.pend[pid]);
    } catch (e) {
      resolved = null;
    }
    if (resolved === undefined) return;
    const amounts = resolved ? resolved.y : null;
    const chops = resolved && resolved.c ? resolved.c : null;
    const toolInfo = chops ? toolInfoFor(groupKey) : null;
    if (amounts) {
      st.log = st.log.filter(e => e.xpid !== pid);
      st.log.forEach(e => {
        if (e.pid !== pid || !Array.isArray(e.ids)) return;
        let sum = 0;
        let tools = 0;
        let ok = true;
        e.ids.forEach(id => {
          if (typeof amounts[id] === "number") sum += amounts[id]; else ok = false;
          if (chops && typeof chops[id] === "number") tools += chops[id];
        });
        if (ok) {
          e.y = sum;
          e.exact = true;
          if (toolInfo) e.tl = roundTools(tools * toolInfo.factor);
        }
      });
    }
    st.log.forEach(e => {
      if (e.pid === pid) {
        delete e.pid;
        delete e.ids;
      }
      if (e.xpid === pid) delete e.xpid;
    });
    delete st.pend[pid];
    changed = true;
  });
  return changed;
}

var yieldListener;

export function dailyHarvestOnYield(fn) {
  yieldListener = typeof fn === "function" ? fn : null;
}

export function dailyHarvestSetYield(groupKey, perNode, iconHtml, nodeQty, econ, farmId, products) {
  if (yieldListener) {
    try {
      yieldListener();
    } catch (e) {}
  }
  const metaStore = freshStore();
  const metaFid = farmId ? String(farmId) : metaStore.__last || "";
  if (metaFarm !== metaFid) {
    Object.keys(yieldMeta).forEach(k => {
      delete yieldMeta[k];
    });
    metaFarm = metaFid;
  }
  const per = typeof perNode === "number" && isFinite(perNode) && perNode > 0 ? perNode : 0;
  const meta = yieldMeta[groupKey] || (yieldMeta[groupKey] = {
    per: 0,
    icon: "",
    nodes: null,
    price: 0,
    feeRate: 0,
    products: null,
    productName: ""
  });
  if (Array.isArray(products)) {
    const clean = products.filter(pr => pr && typeof pr.name === "string" && pr.name).map(pr => ({
      name: pr.name,
      per: typeof pr.per === "number" && isFinite(pr.per) && pr.per > 0 ? pr.per : 0,
      icon: pr.icon || "",
      price: typeof pr.price === "number" && isFinite(pr.price) && pr.price > 0 ? pr.price : 0,
      feeRate: typeof pr.feeRate === "number" && isFinite(pr.feeRate) && pr.feeRate > 0 ? pr.feeRate : 0
    }));
    meta.products = clean.length > 1 ? clean : null;
    meta.productName = clean.length === 1 ? clean[0].name : "";
  }
  if (econ && typeof econ === "object") {
    meta.price = typeof econ.price === "number" && isFinite(econ.price) && econ.price > 0 ? econ.price : 0;
    meta.feeRate = typeof econ.feeRate === "number" && isFinite(econ.feeRate) && econ.feeRate > 0 ? econ.feeRate : 0;
  }
  if (Array.isArray(nodeQty) && nodeQty.length) {
    const map = {};
    nodeQty.forEach(n => {
      if (!n || typeof n.key !== "string" || typeof n.qty !== "number" || !isFinite(n.qty)) return;
      map[n.key.slice(n.key.indexOf(":") + 1)] = n.qty;
    });
    meta.nodes = map;
  }
  if (per) meta.per = per;
  if (iconHtml) meta.icon = iconHtml;
  const store = metaStore;
  const rec = store[metaFid];
  let ymChanged = false;
  if (rec && typeof rec === "object") {
    const ymNext = {
      per: meta.per,
      nodes: meta.nodes,
      products: meta.products ? meta.products.map(pr => ({
        name: pr.name,
        per: pr.per
      })) : null
    };
    rec.ym = rec.ym || {};
    if (JSON.stringify(rec.ym[groupKey] || null) !== JSON.stringify(ymNext)) {
      rec.ym[groupKey] = ymNext;
      ymChanged = true;
    }
  }
  const st = rec && rec.stats ? rec.stats[groupKey] : null;
  if (!st || !Array.isArray(st.log)) {
    if (ymChanged) saveStore();
    return;
  }
  let changed = resolvePending(st, groupKey) || ymChanged;
  if (meta.per) st.log.forEach(e => {
    if (e.y === null || e.y === undefined) {
      if (meta.products) {
        e.p = {};
        let sum = 0;
        meta.products.forEach(pr => {
          const v = e.n * pr.per;
          e.p[pr.name] = v;
          sum += v;
        });
        e.y = sum;
      } else {
        e.y = e.n * meta.per;
      }
      changed = true;
    }
  });
  if (changed) saveStore();
}

const LOG_NODE_GROUPS = [ "Wood", "Stone", "Iron", "Gold", "Crimstone", "Oil" ];

const LOG_KIND_OF = {
  crop: "crop",
  fruit: "fruit",
  greenhouse: "greenhouse"
};

const LOG_VERSION = 2;

function addLogTotal(totals, name, kind, amount, rounds, price, feeRate, ver, tools) {
  const value = Math.round(amount * 100) / 100;
  if (!(value > 0) || !isFinite(value)) return;
  const cur = totals[name];
  const entry = {
    k: kind,
    a: cur ? Math.round((cur.a + value) * 100) / 100 : value
  };
  const toolSum = roundTools((typeof tools === "number" && isFinite(tools) && tools > 0 ? tools : 0) + (cur && cur.tl || 0));
  if (toolSum > 0) entry.tl = toolSum;
  const c = Math.max(cur && cur.c || 0, Number.isFinite(rounds) ? Math.floor(rounds) : 0);
  if (c > 0) entry.c = c;
  if (ver > 0) entry.v = ver;
  const p = typeof price === "number" && isFinite(price) && price > 0 ? price : cur && cur.p || 0;
  if (p > 0) {
    entry.p = Math.round(p * 1e6) / 1e6;
    const f = typeof feeRate === "number" && isFinite(feeRate) && feeRate > 0 && feeRate < 1 ? feeRate : cur && cur.f || 0;
    entry.f = Math.round(f * 1e6) / 1e6;
  }
  totals[name] = entry;
}

function animalLogTotals(totals, groupKey, st) {
  const meta = yieldMeta[groupKey];
  if (!meta) return;
  const rounds = roundsFromStats(st).rounds;
  const dropped = typeof st.dropped === "number" ? st.dropped : 0;
  if (meta.products) {
    const products = meta.products;
    const sumPer = products.reduce((sum, pr) => sum + pr.per, 0);
    const parts = products.map(pr => sumPer > 0 ? dropped * pr.per / sumPer : 0);
    st.log.forEach(e => {
      splitEntryByProduct(e, products).forEach((v, i) => {
        parts[i] += v;
      });
    });
    products.forEach((pr, i) => addLogTotal(totals, pr.name, "animal", parts[i], rounds, pr.price, pr.feeRate, LOG_VERSION));
    return;
  }
  if (!meta.productName) return;
  let amount = dropped;
  st.log.forEach(e => {
    if (typeof e.y === "number") amount += e.y; else if (meta.per) amount += e.n * meta.per;
  });
  addLogTotal(totals, meta.productName, "animal", amount, rounds, meta.price, meta.feeRate, LOG_VERSION);
}

export function dailyHarvestTotals(farmId) {
  const store = freshStore();
  const rec = store[farmId ? String(farmId) : store.__last];
  if (!rec || rec.day !== utcDay(Date.now()) || !rec.stats) return null;
  const totals = {};
  Object.keys(rec.stats).forEach(groupKey => {
    const st = rec.stats[groupKey];
    if (!st || !Array.isArray(st.log) || !st.log.length) return;
    if (st.kind === "animal") {
      animalLogTotals(totals, groupKey, st);
      return;
    }
    let logKind = LOG_KIND_OF[st.kind];
    if (groupKey === "Honey") logKind = "beehive";
    if (LOG_NODE_GROUPS.includes(groupKey)) logKind = "node";
    if (!logKind) return;
    const per = yieldMeta[groupKey] && yieldMeta[groupKey].per || 0;
    let amount = typeof st.dropped === "number" ? st.dropped : 0;
    st.log.forEach(e => {
      if (typeof e.y === "number") amount += e.y; else if (per) amount += e.n * per;
    });
    const gm = yieldMeta[groupKey];
    const toolsUsed = logKind === "node" ? (typeof st.droppedTl === "number" ? st.droppedTl : 0) + st.log.reduce((sum, e) => sum + (typeof e.tl === "number" ? e.tl : 0), 0) : 0;
    addLogTotal(totals, groupKey, logKind, amount, roundsFromStats(st).rounds, gm && gm.price, gm && gm.feeRate, logKind === "beehive" ? 0 : LOG_VERSION, toolsUsed);
  });
  const bris = rec.bris;
  if (bris && bris.a > 0) {
    const bp = lookupPrice("Pig Bristles");
    addLogTotal(totals, "Pig Bristles", "animal", bris.a, bris.c, bp.price, bp.fee);
  }
  const caveKey = farmId ? String(farmId) : store.__last;
  const dug = caveKey ? readCaveDugToday(caveKey, Date.now()) : {};
  Object.keys(dug).forEach(name => {
    if (!CAVE_BEETLE_RE.test(name)) return;
    const bp = lookupPrice(name);
    addLogTotal(totals, name, "cave", dug[name], 0, bp.price, bp.fee);
  });
  const cookTotals = rec.cook && rec.cook.totals ? rec.cook.totals : {};
  Object.keys(cookTotals).forEach(name => {
    const t = cookTotals[name];
    if (!t || !LOG_NAME_RE.test(name)) return;
    addLogTotal(totals, name, t.k === "composter" ? "composter" : "cooking", t.a, t.c, t.p, t.f);
  });
  const coin = rec.coin;
  const round2 = v => Math.round(v * 100) / 100;
  const coins = coin && (coin.s > 0 || coin.e > 0) ? {
    e: round2(coin.e),
    s: round2(coin.s)
  } : null;
  if (coins) {
    if (typeof coin.b === "number" && isFinite(coin.b)) coins.b = round2(coin.b);
    if (coin.est) coins.est = 1;
  }
  return {
    day: rec.day,
    totals: totals,
    coins: coins
  };
}

function store0Last() {
  return freshStore().__last || "";
}

export function dailyOrdinal(n) {
  const mod100 = n % 100;
  if (mod100 >= 11 && mod100 <= 13) return `${n}th`;
  const mod10 = n % 10;
  if (mod10 === 1) return `${n}st`;
  if (mod10 === 2) return `${n}nd`;
  if (mod10 === 3) return `${n}rd`;
  return `${n}th`;
}

const KIND_META = {
  wood: {
    verb: "Chopped",
    action: "chopped",
    unit: "nodes",
    palette: [ "#a0673a", "#d8a060", "#6b4226" ]
  },
  stone: {
    verb: "Mined",
    action: "mined",
    unit: "nodes",
    palette: [ "#b8bcc8", "#7a7f90", "#e6e9f0" ]
  },
  iron: {
    verb: "Mined",
    action: "mined",
    unit: "nodes",
    palette: [ "#9fb4c9", "#e8eef5", "#c27a4a" ]
  },
  gold: {
    verb: "Mined",
    action: "mined",
    unit: "nodes",
    palette: [ "#ffd23f", "#fff3a0", "#d69a1e" ]
  },
  crimstone: {
    verb: "Mined",
    action: "mined",
    unit: "nodes",
    palette: [ "#e43b44", "#ff8a8a", "#a1202a" ]
  },
  honey: {
    verb: "Collected",
    action: "collected",
    unit: "nodes",
    palette: [ "#ffd23f", "#fff3a0", "#d69a1e" ]
  },
  oil: {
    verb: "Drilled",
    action: "drilled",
    unit: "reserves",
    palette: [ "#2b2b3a", "#6a5acd", "#9a8cff" ]
  },
  crop: {
    verb: "Harvested",
    action: "harvested",
    unit: "plots",
    palette: [ "#5fcf4a", "#c9f07a", "#ffe14a" ]
  },
  fruit: {
    verb: "Harvested",
    action: "harvested",
    unit: "patches",
    palette: [ "#ff6b6b", "#ffe14a", "#5fcf4a" ]
  },
  flower: {
    verb: "Harvested",
    action: "harvested",
    unit: "beds",
    palette: [ "#ff8ac8", "#ffe14a", "#c9f07a" ]
  },
  greenhouse: {
    verb: "Harvested",
    action: "harvested",
    unit: "pots",
    palette: [ "#5fcf4a", "#9fe6ff", "#ffe14a" ]
  },
  animal: {
    verb: "Collected",
    action: "collected",
    unit: "animals",
    palette: [ "#ffffff", "#f5d36b", "#ffb347" ]
  },
  cooking: {
    verb: "Collected",
    action: "collected",
    unit: "slots",
    palette: [ "#ffb347", "#fff3a0", "#e43b44" ]
  },
  composter: {
    verb: "Collected",
    action: "collected",
    unit: "batches",
    palette: [ "#8a5a2b", "#5fcf4a", "#c9f07a" ]
  }
};

const KIND_NOUN = {
  Wood: "Tree",
  Stone: "Stone",
  Iron: "Iron",
  Gold: "Gold",
  Crimstone: "Crimstone",
  Oil: "Oil",
  Honey: "Beehive"
};

const PARTICLES = [ [ 2, 9, -5, -7 ], [ 9, 2, 6, -6 ], [ 11, 8, 7, 3 ], [ 4, 11, -6, 4 ], [ 6, 1, 1, -8 ], [ 12, 5, 8, -2 ] ];

function effectSvg(kind) {
  const meta = KIND_META[kind];
  if (!meta) return "";
  const rects = PARTICLES.map(([x, y, dx, dy], i) => `<rect class="dh-p" x="${x}" y="${y}" width="2" height="2" fill="${meta.palette[i % meta.palette.length]}" style="--dx:${dx}px;--dy:${dy}px;animation-delay:${i * 18}ms"/>`).join("");
  return `<svg class="dh-fx" viewBox="0 0 14 14" width="14" height="14" shape-rendering="crispEdges" aria-hidden="true"><path class="dh-slash" d="M2 2h2v2h2v2h2v2h2v2h2" fill="none" stroke="#ffffff" stroke-width="1.4"/>${rects}</svg>`;
}

function escapeAttr(s) {
  return String(s).replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

export function dailyHarvestBadgeHtml(groupKey, kind, iconHtml, farmId) {
  if (!KIND_META[kind]) return "";
  const info = kind === "cooking" || kind === "composter" ? dailyCookingInfo(groupKey, farmId) : dailyHarvestInfo(groupKey, farmId);
  if (!info) return "";
  return `<span class="daily-harvest-badge guro-frame dh-${kind}" role="button" tabindex="0" data-dh-key="${escapeAttr(groupKey)}" data-dh-kind="${kind}" data-dh-farm="${escapeAttr(farmId || "")}"><span class="dh-ord">${info.estimated ? "~" : ""}${info.rounds}x</span><span class="dh-icon">${iconHtml || ""}${effectSvg(kind)}</span></span>`;
}

function formatResetIn(now) {
  const next = utcDayStart(now) + 864e5;
  const mins = Math.max(0, Math.floor((next - now) / 6e4));
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${h}h ${String(m).padStart(2, "0")}m`;
}

function formatClock(ms) {
  if (!ms) return "Just now";
  try {
    return new Date(ms).toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit"
    });
  } catch (e) {
    return "Today";
  }
}

function formatLogClock(ms) {
  const d = new Date(ms);
  const h = d.getHours();
  const m = String(d.getMinutes()).padStart(2, "0");
  return `${h % 12 || 12}:${m}${h < 12 ? "AM" : "PM"}`;
}

const LOG_MERGE_GAP = 10 * 60 * 1000;

function formatLogYield(y) {
  return y.toLocaleString("en-US", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}

function splitEntryByProduct(e, products) {
  if (e.p && typeof e.p === "object") {
    return products.map(pr => typeof e.p[pr.name] === "number" ? e.p[pr.name] : 0);
  }
  const sumPer = products.reduce((sum, pr) => sum + pr.per, 0);
  if (typeof e.y === "number") {
    return products.map(pr => sumPer > 0 ? e.y * pr.per / sumPer : 0);
  }
  return products.map(pr => e.n * pr.per);
}

function multiYieldHtml(values, products) {
  const lines = values.map((v, i) => v > 1e-9 ? `<span class="dh-log-yield">+${formatLogYield(v)}<span class="dh-log-ico">${products[i].icon}</span></span>` : "").join("");
  return `<span class="dh-log-multi">${lines || "—"}</span>`;
}

function logHtmlProducts(meta, info) {
  const products = meta.products;
  const sorted = info.log.slice().sort((a, b) => b.t - a.t);
  if (!sorted.length) return "";
  const totals = products.map(() => 0);
  const sumPer = products.reduce((sum, pr) => sum + pr.per, 0);
  products.forEach((pr, i) => {
    totals[i] += sumPer > 0 ? (info.dropped || 0) * pr.per / sumPer : 0;
  });
  const merged = [];
  sorted.forEach(e => {
    const parts = splitEntryByProduct(e, products);
    parts.forEach((v, i) => {
      totals[i] += v;
    });
    const last = merged[merged.length - 1];
    if (last && last.t - e.t <= LOG_MERGE_GAP) {
      parts.forEach((v, i) => {
        last.parts[i] += v;
      });
      return;
    }
    merged.push({
      t: e.t,
      parts: parts
    });
  });
  const rows = merged.map(e => `<div class="dh-log-row dh-log-row-multi"><span>${formatLogClock(e.t)}</span>${multiYieldHtml(e.parts, products)}</div>`).join("");
  let gross = 0;
  let fee = 0;
  products.forEach((pr, i) => {
    const g = totals[i] * pr.price;
    gross += g;
    fee += g * pr.feeRate;
  });
  const net = gross - fee;
  const valueRows = gross > 0 ? `<div class="dh-log-row"><span>Gross</span><span class="dh-log-yield">${formatLogYield(gross)}<span class="dh-log-ico">${FLOWER_ICON}</span></span></div><div class="dh-log-row"><span>Net</span><span class="dh-log-yield">${formatLogYield(net)}<span class="dh-log-ico">${FLOWER_ICON}</span></span></div>` : "";
  const sumHtml = `<div class="dh-log-sum"><div class="dh-log-row dh-log-row-multi dh-log-total"><span>Total</span>${multiYieldHtml(totals, products)}</div>${valueRows}</div>`;
  return `<div class="dh-pop-log guro-frame"><div class="dh-log-head"><span>Time</span><span>Harvested</span></div><div class="dh-log-list">${rows}</div>${sumHtml}</div>`;
}

function logHtml(groupKey, info) {
  const meta = yieldMeta[groupKey] || {
    per: 0,
    icon: "",
    price: 0,
    feeRate: 0,
    products: null
  };
  if (meta.products) return logHtmlProducts(meta, info);
  const sorted = info.log.slice().sort((a, b) => b.t - a.t);
  if (!sorted.length) return "";
  let total = info.dropped || 0;
  let toolTotal = info.droppedTl || 0;
  const merged = [];
  sorted.forEach(e => {
    const y = typeof e.y === "number" ? e.y : meta.per ? e.n * meta.per : null;
    const tl = typeof e.tl === "number" ? e.tl : 0;
    if (y !== null) total += y;
    toolTotal += tl;
    const last = merged[merged.length - 1];
    if (last && last.t - e.t <= LOG_MERGE_GAP) {
      if (y !== null) last.y = (last.y || 0) + y;
      last.tl += tl;
      return;
    }
    merged.push({
      t: e.t,
      y,
      tl: tl
    });
  });
  const toolInfo = toolTotal > 0 ? toolInfoFor(groupKey) : null;
  const toolIcon = toolInfo ? toolInfo.icon : "";
  const rows = merged.map(e => {
    const amount = e.y === null ? "—" : `+${formatLogYield(e.y)}`;
    if (!toolInfo) return `<div class="dh-log-row"><span>${formatLogClock(e.t)}</span><span class="dh-log-yield">${amount}<span class="dh-log-ico">${meta.icon}</span></span></div>`;
    const used = e.tl > 0 ? `<span class="dh-log-yield dh-log-tools">×${fmtTools(e.tl)}<span class="dh-log-ico">${toolIcon}</span></span>` : `<span class="dh-log-tools">—</span>`;
    return `<div class="dh-log-row dh-log-row-tools"><span>${formatLogClock(e.t)}</span>${used}<span class="dh-log-yield dh-log-yield-end">${amount}<span class="dh-log-ico">${meta.icon}</span></span></div>`;
  }).join("");
  const toolRow = toolInfo ? `<div class="dh-log-row"><span>Tools used</span><span class="dh-log-yield">×${fmtTools(roundTools(toolTotal))}<span class="dh-log-ico">${toolIcon}</span></span></div>` : "";
  const headHtml = toolInfo ? `<div class="dh-log-head dh-log-head-tools"><span>Time</span><span>Tools</span><span>Harvested</span></div>` : `<div class="dh-log-head"><span>Time</span><span>Harvested</span></div>`;
  const gross = total * meta.price;
  const net = gross - gross * meta.feeRate;
  const valueRows = meta.price > 0 ? `<div class="dh-log-row"><span>Gross</span><span class="dh-log-yield">${formatLogYield(gross)}<span class="dh-log-ico">${FLOWER_ICON}</span></span></div><div class="dh-log-row"><span>Net</span><span class="dh-log-yield">${formatLogYield(net)}<span class="dh-log-ico">${FLOWER_ICON}</span></span></div>` : "";
  const sumHtml = `<div class="dh-log-sum"><div class="dh-log-row dh-log-total"><span>Total</span><span class="dh-log-yield">+${formatLogYield(total)}<span class="dh-log-ico">${meta.icon}</span></span></div>${toolRow}${valueRows}</div>`;
  return `<div class="dh-pop-log guro-frame">${headHtml}<div class="dh-log-list">${rows}</div>${sumHtml}</div>`;
}

function closeDailyPop() {
  const el = document.getElementById("dailyHarvestPop");
  if (el) el.remove();
  document.documentElement.classList.remove("dh-pop-lock");
}

function cookingItemLogHtml(entry) {
  const it = entry.item;
  const icon = iconProvider ? iconProvider(entry.name) : "";
  const sorted = it.log.slice().sort((a, b) => b.t - a.t);
  const merged = [];
  sorted.forEach(e => {
    const last = merged[merged.length - 1];
    if (last && last.t - e.t <= LOG_MERGE_GAP) {
      last.a += e.a;
      if (e.e) last.e = 1;
      return;
    }
    merged.push({
      t: e.t,
      a: e.a,
      e: e.e ? 1 : 0
    });
  });
  const rows = merged.map(e => `<div class="dh-log-row"><span>${formatLogClock(e.t)}</span><span class="dh-log-yield">${e.e ? "~" : ""}+${formatLogYield(e.a)}<span class="dh-log-ico">${icon}</span></span></div>`).join("");
  const gross = it.a * it.p;
  const net = gross - gross * it.f;
  const valueRows = gross > 0 ? `<div class="dh-log-row"><span>Gross</span><span class="dh-log-yield">${formatLogYield(gross)}<span class="dh-log-ico">${FLOWER_ICON}</span></span></div><div class="dh-log-row"><span>Net</span><span class="dh-log-yield">${formatLogYield(net)}<span class="dh-log-ico">${FLOWER_ICON}</span></span></div>` : "";
  const head = `<div class="dh-log-head"><span class="dh-log-yield"><span class="dh-log-ico">${icon}</span>${escapeAttr(entry.name)}</span><span>${it.c}x</span></div>`;
  const sumHtml = `<div class="dh-log-sum"><div class="dh-log-row dh-log-total"><span>Total</span><span class="dh-log-yield">+${formatLogYield(it.a)}<span class="dh-log-ico">${icon}</span></span></div>${valueRows}</div>`;
  return `<div class="dh-pop-log guro-frame">${head}<div class="dh-log-list">${rows}</div>${sumHtml}</div>`;
}

function openCookingPop(badgeEl, kind) {
  const building = badgeEl.getAttribute("data-dh-key");
  const meta = KIND_META[kind];
  const info = dailyCookingInfo(building, badgeEl.getAttribute("data-dh-farm") || "");
  if (!info) return;
  closeDailyPop();
  const iconEl = badgeEl.querySelector(".dh-icon");
  const iconHtml = iconEl ? iconEl.innerHTML : "";
  const times = `${info.estimated ? "~" : ""}${info.rounds}x`;
  const safeName = escapeAttr(building);
  const bodyText = kind === "composter" ? `Your ${safeName} has finished and handed over ${times} today. Each finished batch that is collected counts as one harvest, and the fertiliser and worms below keep their own records.` : `Your ${safeName} has finished and handed over ${times} today. Each finished cook that is collected counts as one harvest, and every item below keeps its own record.`;
  const now = Date.now();
  const itemsHtml = info.items.map(cookingItemLogHtml).join("");
  const farm = badgeEl.getAttribute("data-dh-farm") || store0Last();
  const html = `<div class="dh-pop-back" id="dailyHarvestPop"><div class="dh-pop guro-frame dh-${kind}" role="dialog" aria-modal="true"><div class="dh-pop-top"><span class="dh-pop-top-title">Daily Harvest · UTC</span><span class="dh-pop-top-acts"><button type="button" class="dh-pop-log-btn" data-dh-log="${escapeAttr(farm)}">Log</button><button type="button" class="dh-pop-x" data-dh-close="1" aria-label="Close"></button></span></div><div class="dh-pop-head"><span class="dh-pop-icon guro-frame dh-icon">${iconHtml}</span><div class="dh-pop-headtext guro-frame"><div class="dh-pop-title dh-pop-title-solo">${safeName}</div></div><span class="dh-pop-ord guro-frame">${times}</span></div><div class="dh-pop-main guro-frame">${meta.verb} <b>${times}</b> today</div><p class="dh-pop-text">${bodyText}</p><div class="dh-pop-stats guro-frame"><div class="dh-stat"><span>Accuracy</span><b>${info.estimated ? "Estimated" : "Exact"}</b></div><div class="dh-stat"><span>Items</span><b>${info.items.length}</b></div><div class="dh-stat"><span>Last collected</span><b>${formatClock(info.lastAt)}</b></div><div class="dh-stat"><span>Resets in</span><b>${formatResetIn(now)}</b></div></div>${itemsHtml}${info.estimated ? `<p class="dh-pop-text dh-pop-note">Rows marked with ~ were collected between syncs and are estimated from your lifetime activity counters.</p>` : ""}</div></div>`;
  document.body.insertAdjacentHTML("beforeend", html);
  document.documentElement.classList.add("dh-pop-lock");
}

function openDailyPop(badgeEl) {
  const groupKey = badgeEl.getAttribute("data-dh-key");
  const kind = badgeEl.getAttribute("data-dh-kind");
  if (kind === "cooking" || kind === "composter") {
    openCookingPop(badgeEl, kind);
    return;
  }
  const meta = KIND_META[kind];
  const info = dailyHarvestInfo(groupKey, badgeEl.getAttribute("data-dh-farm") || "");
  if (!meta || !info) return;
  closeDailyPop();
  const noun = KIND_NOUN[groupKey] || groupKey;
  const iconEl = badgeEl.querySelector(".dh-icon");
  const iconHtml = iconEl ? iconEl.innerHTML : "";
  const times = `${info.estimated ? "~" : ""}${info.rounds}x`;
  const safeNoun = escapeAttr(noun);
  const bodyText = kind === "animal" ? `Your ${safeNoun} produce has been ${meta.action} ${times} today. A round is counted once all of your ${safeNoun} animals (${info.need} of ${info.total}) have been ${meta.action}.` : `Your ${safeNoun} ${meta.unit} have been ${meta.action} ${times} today. A round is counted once all of them (${info.need} of ${info.total}) have been ${meta.action}.`;
  const now = Date.now();
  const html = `<div class="dh-pop-back" id="dailyHarvestPop"><div class="dh-pop guro-frame dh-${kind}" role="dialog" aria-modal="true"><div class="dh-pop-top"><span class="dh-pop-top-title">Daily Harvest · UTC</span><span class="dh-pop-top-acts"><button type="button" class="dh-pop-log-btn" data-dh-log="${escapeAttr(badgeEl.getAttribute("data-dh-farm") || store0Last())}">Log</button><button type="button" class="dh-pop-x" data-dh-close="1" aria-label="Close"></button></span></div><div class="dh-pop-head"><span class="dh-pop-icon guro-frame dh-icon">${iconHtml}</span><div class="dh-pop-headtext guro-frame"><div class="dh-pop-title dh-pop-title-solo">${escapeAttr(noun)}</div></div><span class="dh-pop-ord guro-frame">${info.estimated ? "~" : ""}${info.rounds}x</span></div><div class="dh-pop-main guro-frame">${meta.verb} <b>${times}</b> today</div><p class="dh-pop-text">${bodyText}</p><div class="dh-pop-stats guro-frame"><div class="dh-stat"><span>Accuracy</span><b>${info.estimated ? "Estimated" : "Exact"}</b></div><div class="dh-stat"><span>Next round</span><b>${info.nextProgress} / ${info.need}</b></div><div class="dh-stat"><span>Last completed</span><b>${formatClock(info.lastAt)}</b></div><div class="dh-stat"><span>Resets in</span><b>${formatResetIn(now)}</b></div></div>${logHtml(groupKey, info)}${info.estimated ? `<p class="dh-pop-text dh-pop-note">Includes harvests made between syncs, estimated from your lifetime activity counters.</p>` : ""}</div></div>`;
  document.body.insertAdjacentHTML("beforeend", html);
  document.documentElement.classList.add("dh-pop-lock");
}

document.addEventListener("click", e => {
  const target = e.target;
  if (!target || !target.closest) return;
  const logBtn = target.closest("[data-dh-log]");
  if (logBtn) {
    e.stopPropagation();
    e.preventDefault();
    document.dispatchEvent(new CustomEvent("dh-open-log", {
      detail: {
        farm: logBtn.getAttribute("data-dh-log") || ""
      }
    }));
    return;
  }
  if (target.closest("[data-dh-close]")) {
    e.stopPropagation();
    closeDailyPop();
    return;
  }
  const backdrop = target.closest(".dh-pop-back");
  if (backdrop && target === backdrop) {
    closeDailyPop();
    return;
  }
  const badge = target.closest(".daily-harvest-badge");
  if (!badge) return;
  e.stopPropagation();
  e.preventDefault();
  openDailyPop(badge);
}, true);

document.addEventListener("keydown", e => {
  if (e.key === "Escape") closeDailyPop();
  if ((e.key === "Enter" || e.key === " ") && e.target && e.target.classList && e.target.classList.contains("daily-harvest-badge")) {
    e.preventDefault();
    e.stopPropagation();
    openDailyPop(e.target);
  }
}, true);
